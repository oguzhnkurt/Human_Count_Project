# HumanCounting-ImageProcess-Python-
Human Counting from Video in Python
//Frame rates in code must be adjust to specific for used video. User enter path after execute the code.
